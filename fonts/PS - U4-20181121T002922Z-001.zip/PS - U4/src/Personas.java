
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rob
 */
public class Personas {
    
    private ArrayList<Persona> personas;
    
    public Personas(){
        this.personas = new ArrayList<>();
    }
    
    
    
    public static Personas listaPredeterminada(){
        Personas p = new Personas();
        p.getPersonas().add(new Persona(21,"Roberto Guerrero","ROGU"));
        p.getPersonas().add(new Persona(20,"Fernando Rodríguez","FERO"));
        p.getPersonas().add(new Persona(30,"Anibal Ruiz","ANRU"));
        p.getPersonas().add(new Persona(45,"Mario Leyva","MALE"));
        p.getPersonas().add(new Persona(10,"Joel Torres","JOTO"));

        return p;
    }
    
    public boolean anadirPersona(Persona persona){
        
        if(!this.getPersonas().contains(persona)){
            this.getPersonas().add(persona);
            return true;        
        }
        
        return false;
        
        
        
    }
    
    public boolean eliminarPersona(String curp){
        if(this.getPersonas().contains(new Persona(curp))){
            this.getPersonas().remove(new Persona(curp));
            return true;        
        }
        return false;
    }
    
    public boolean modificarPersona(Persona reemplazo,String curpExistente){
        if(this.getPersonas().contains(new Persona(curpExistente))){
           
            for (int i = 0; i < this.getPersonas().size(); i++) {
                if(this.getPersonas().get(i).equals(new Persona(curpExistente))){
                    this.getPersonas().set(i, reemplazo);
                    return true;
                }
            }
            
        }
        return false;
    }
    
    public boolean verificarExistencia(String curp){
        return this.getPersonas().contains(new Persona(curp));
    }
    
    public int devuelveTamano(){
        return this.getPersonas().size();
    }

    public Persona devuelvePersona(String curp){
        if(this.getPersonas().contains(new Persona(curp))){
            for (Persona persona : personas) {
                if(persona.equals(new Persona(curp))){
                    return persona;
                }
            }
        }
        
        return null;
    }
    
    public Persona devuelvePersonaMayorEdad(){
        
        Persona mayor = null;
        
        try{
            for (Persona persona : personas) {
                if(mayor != null){
                    if(mayor.getEdad() < persona.getEdad()){
                        mayor = persona;
                    }  
                }else{
                    mayor = persona;
                } 
            }
            return mayor;
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        return mayor;
    }
    
    public Persona devuelvePersonaMenorEdad(){
        Persona menor = null;
        
        try{
            for (Persona persona : personas) {
                if(menor != null){
                    if(menor.getEdad() > persona.getEdad()){
                        menor = persona;
                    }  
                }else{
                    menor = persona;
                } 
            }
            return menor;
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
        return menor;
    }
    
    public boolean eliminarMasViejo(){
        
        Persona persona = devuelvePersonaMayorEdad();
        return this.getPersonas().remove(persona);
        
    }
    
    public boolean eliminarMasJoven(){
        Persona persona = devuelvePersonaMenorEdad();
        return this.getPersonas().remove(persona);
    }
    
    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }
    
    
    
    
}
