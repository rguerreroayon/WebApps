/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rob
 */
public class PersonasTest {
    
    public PersonasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }



    /**
     * Test of anadirPersona method, of class Personas.
     */
    @Test
    public void testAnadirPersona() {
        System.out.println("anadirPersona");
        Persona persona = new Persona(30,"Diaz Torres","DITO");
        
        Personas personas = Personas.listaPredeterminada();
        boolean resultadoEsperado = true;
        boolean resultadoObtenido = personas.anadirPersona(persona);
        assertEquals(resultadoEsperado,resultadoObtenido);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarPersona method, of class Personas.
     */
    @Test
    public void testEliminarPersona() {
        System.out.println("eliminarPersona");
        String curp = "ROGU";
        Personas instance = Personas.listaPredeterminada();
        boolean expResult = true;
        boolean result = instance.eliminarPersona(curp);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of modificarPersona method, of class Personas.
     */
    @Test
    public void testModificarPersona() {
        System.out.println("modificarPersona");
        Persona reemplazo = new Persona(30,"Diaz Torres","DITO");
        String curpExistente = "ROGU";
        Personas instance = Personas.listaPredeterminada();
        boolean expResult = true;
        boolean result = instance.modificarPersona(reemplazo, curpExistente);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of verificarExistencia method, of class Personas.
     */
    @Test
    public void testVerificarExistencia() {
        System.out.println("verificarExistencia");
        String curp = "ROGU";
        Personas instance = Personas.listaPredeterminada();
        boolean expResult = true;
        boolean result = instance.verificarExistencia(curp);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devuelveTamano method, of class Personas.
     */
    @Test
    public void testDevuelveTamano() {
        System.out.println("devuelveTamano");
        Personas instance = Personas.listaPredeterminada();
        int expResult = 5;
        int result = instance.devuelveTamano();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devuelvePersona method, of class Personas.
     */
    @Test
    public void testDevuelvePersona() {
        System.out.println("devuelvePersona");
        String curp = "ROGU";
        Personas instance = Personas.listaPredeterminada();
        Persona expResult = new Persona(21,"Roberto Guerrero","ROGU");
        Persona result = instance.devuelvePersona(curp);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devuelvePersonaMayorEdad method, of class Personas.
     */
    @Test
    public void testDevuelvePersonaMayorEdad() {
        System.out.println("devuelvePersonaMayorEdad");
        Personas instance = Personas.listaPredeterminada();
        Persona expResult = new Persona(45,"Mario Leyva","MALE");
        Persona result = instance.devuelvePersonaMayorEdad();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of devuelvePersonaMenorEdad method, of class Personas.
     */
    @Test
    public void testDevuelvePersonaMenorEdad() {
        System.out.println("devuelvePersonaMenorEdad");
        Personas instance = Personas.listaPredeterminada();
        Persona expResult = new Persona(10,"Joel Torres","JOTO");
        Persona result = instance.devuelvePersonaMenorEdad();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarMasViejo method, of class Personas.
     */
    @Test
    public void testEliminarMasViejo() {
        System.out.println("eliminarMasViejo");
        Personas instance = Personas.listaPredeterminada();
        boolean expResult = true;
        boolean result = instance.eliminarMasViejo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarMasJoven method, of class Personas.
     */
    @Test
    public void testEliminarMasJoven() {
        System.out.println("eliminarMasJoven");
        Personas instance = Personas.listaPredeterminada();
        boolean expResult = true;
        boolean result = instance.eliminarMasJoven();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

 
}
